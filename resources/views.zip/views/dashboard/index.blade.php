{{-- resources/views/dashboard/index.blade.php --}}
@extends('layout.masterpage')

@section('title', 'Dashboard')

@section('content')
<div style="display:flex; flex-direction:column; gap:1.5rem; max-width:1400px;">

    {{-- Header --}}
    <div style="display:flex; flex-direction:column; gap:1rem;">
        <div style="display:flex; align-items:flex-start; justify-content:space-between; flex-wrap:wrap; gap:1rem;">
            <div>
                <h1 style="font-size:1.75rem; font-weight:700; letter-spacing:-0.02em; margin:0 0 0.25rem;">
                    Bienvenido, {{ Auth::user()->name ?? $user->name ?? 'Explorer' }} 👋
                </h1>
                <p style="color:var(--muted-foreground); margin:0; font-size:0.9375rem;">
                    Aquí tienes un resumen de tu actividad reciente
                </p>
            </div>
            <a href="{{ route('spots.index') }}" class="btn btn-primary">
                Explorar Spots
                <i data-lucide="arrow-right" style="width:1rem;height:1rem;"></i>
            </a>
        </div>
    </div>

    {{-- Stats Grid --}}
    <div style="display:grid; gap:1rem; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));">
        @php
            $stats = [
                ['title'=>'Spots Añadidos',  'value'=>$user->spots_count ?? 0,       'change'=>'+3 este mes',       'icon'=>'map-pin',      'color'=>'var(--primary)'],
                ['title'=>'Reputación',       'value'=>$user->reputation ?? 0,        'change'=>'+127 esta semana',  'icon'=>'star',         'color'=>'var(--accent)'],
                ['title'=>'Comunidades',      'value'=>$user->communities_count ?? 0, 'change'=>'Activas',           'icon'=>'users',        'color'=>'oklch(0.55 0.15 145)'],
                ['title'=>'Logros',           'value'=>$user->badges_count ?? 0,      'change'=>'Desbloqueados',     'icon'=>'award',        'color'=>'oklch(0.75 0.15 85)'],

            ];
        @endphp

        @foreach($stats as $stat)
        <div class="card stat-card" style="color:{{ $stat['color'] }}">
            <div class="card-header" style="display:flex; flex-direction:row; align-items:center; justify-content:space-between;">
                <p class="card-title" style="font-size:0.8125rem; font-weight:500; color:var(--muted-foreground);">
                    {{ $stat['title'] }}
                </p>
                <i data-lucide="{{ $stat['icon'] }}"
                    style="width:1.125rem;height:1.125rem; color:{{ $stat['color'] }};"></i>
            </div>
            <div class="card-content">
                <p style="font-size:1.875rem; font-weight:700; color:var(--card-foreground); margin:0 0 0.25rem;">
                    {{ number_format($stat['value']) }}
                </p>
                <p style="font-size:0.75rem; color:var(--muted-foreground); margin:0;">
                    {{ $stat['change'] }}
                </p>
            </div>
        </div>
        @endforeach
    </div>

    {{-- Two-column layout --}}
    <div style="display:grid; gap:1rem; grid-template-columns:1fr 1fr;">

        {{-- Recent Spots --}}
        <div class="card" style="grid-column: span 1;">
            <div class="card-header" style="display:flex; justify-content:space-between; align-items:center;">
                <h2 class="card-title">Spots Recientes</h2>
                <a href="{{ route('spots.index') }}"
                    style="font-size:0.8125rem; color:var(--muted-foreground); text-decoration:none; display:flex; align-items:center; gap:0.25rem;">
                    Ver todos
                    <i data-lucide="arrow-right" style="width:0.875rem;height:0.875rem;"></i>
                </a>
            </div>
            <div class="card-content" style="padding-top:0;">
                @forelse($recentSpots ?? [] as $spot)
                <a href="{{ route('spots.show', $spot) }}"
                    style="display:flex; align-items:center; gap:0.875rem; padding:0.75rem 0;
                    border-bottom:1px solid var(--border); text-decoration:none; color:inherit;
                    transition:opacity 150ms;"
                    onmouseover="this.style.opacity='0.75'" onmouseout="this.style.opacity='1'">
                    {{-- Thumbnail --}}
                    <div style="width:3rem; height:3rem; border-radius:calc(var(--radius) - 2px);
                        background:var(--secondary); overflow:hidden; flex-shrink:0;">
                        @if($spot->image)
                            <img src="{{ $spot->image }}" alt="{{ $spot->name }}"
                                style="width:100%;height:100%;object-fit:cover;" />
                        @else
                            <div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">
                                <i data-lucide="image" style="width:1.25rem;height:1.25rem; color:var(--muted-foreground);"></i>
                            </div>
                        @endif
                    </div>
                    <div style="flex:1; min-width:0;">
                        <p style="font-weight:500; font-size:0.875rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; margin:0 0 0.25rem;">
                            {{ $spot->name }}
                        </p>
                        <div style="display:flex; align-items:center; gap:0.5rem;">
                            <i data-lucide="map-pin" style="width:0.75rem;height:0.75rem; color:var(--muted-foreground);"></i>
                            <span style="font-size:0.75rem; color:var(--muted-foreground);">{{ $spot->location }}</span>
                        </div>
                    </div>
                    {{-- Difficulty badge --}}
                    @php
                        $diffColors = ['facil'=>'var(--primary)', 'medio'=>'var(--accent)', 'dificil'=>'var(--destructive)'];
                        $dc = $diffColors[$spot->difficulty] ?? 'var(--muted-foreground)';
                    @endphp
                    <span class="badge" style="background:color-mix(in oklch, {{ $dc }} 15%, transparent); color:{{ $dc }};">
                        {{ ucfirst($spot->difficulty) }}
                    </span>
                </a>
                @empty
                <div style="padding:2rem 0; text-align:center; color:var(--muted-foreground);">
                    <i data-lucide="map-pin" style="width:2rem;height:2rem; margin-bottom:0.75rem; opacity:0.4;"></i>
                    <p style="font-size:0.875rem;">Aún no has añadido spots</p>
                    <a href="{{ route('spots.create') }}" class="btn btn-primary" style="margin-top:0.75rem; display:inline-flex;">
                        Añadir Spot
                    </a>
                </div>
                @endforelse
            </div>
        </div>

        {{-- Activity Feed --}}
        <div class="card">
            <div class="card-header">
                <h2 class="card-title">Actividad Reciente</h2>
            </div>
            <div class="card-content" style="padding-top:0;">
                @forelse($recentActivity ?? [] as $activity)
                <div style="display:flex; gap:0.875rem; padding:0.75rem 0; border-bottom:1px solid var(--border);">
                    {{-- User avatar --}}
                    <div class="avatar"
                        style="width:2.25rem; height:2.25rem; font-size:0.875rem;
                        background:var(--primary); color:var(--primary-foreground); flex-shrink:0;">
                        {{ strtoupper(substr($activity->user->name ?? 'U', 0, 1)) }}
                    </div>
                    <div style="flex:1; min-width:0;">
                        <p style="font-size:0.875rem; margin:0 0 0.25rem;">
                            <span style="font-weight:600;">{{ $activity->user->name ?? 'Usuario' }}</span>
                            {{ $activity->description }}
                        </p>
                        <div style="display:flex; align-items:center; gap:0.375rem; color:var(--muted-foreground);">
                            <i data-lucide="clock" style="width:0.75rem;height:0.75rem;"></i>
                            <span style="font-size:0.75rem;">{{ $activity->created_at->diffForHumans() }}</span>
                        </div>
                    </div>
                </div>
                @empty
                <div style="padding:2rem 0; text-align:center; color:var(--muted-foreground);">
                    <p style="font-size:0.875rem;">Sin actividad reciente</p>
                </div>
                @endforelse
            </div>
        </div>

    </div>

</div>
@endsection
